using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Dungeon : MonoBehaviour
{
    public GameObject System;
    public GameObject Content;
    public float curtime;
    public float cooltime;
    // Start is called before the first frame update
    void Start()
    {
        Content = GameObject.Find("Content");
    }

    // Update is called once per frame
    void Update()
    {
        curtime += Time.deltaTime;
        if(curtime >= cooltime)
        {
            int rand = Random.Range(1, 26);
            GameObject systems = Instantiate(System);
            systems.transform.SetParent(Content.transform);
            systems.GetComponent<Text>().text = $"Damage {rand}�� ����";
            curtime = 0;
        }
        if(Content.transform.childCount >= 10)
        { 
           Destroy(Content.transform.GetChild(0).gameObject);
        }
        
    }
}
