using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class MyState : MonoBehaviour
{
    public Text myState;
    public Image Myimage;

    public float curtime;

    public EnemyState enemyState;
    public Image Enemyimage;
    // Start is called before the first frame update
    void Start()
    {
        Enemyimage = GameObject.Find("Enemyimage").GetComponent<Image>();
        enemyState = GameObject.Find("System").GetComponent<EnemyState>();
        myState = GameObject.Find("MyState").GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        curtime += Time.deltaTime;
        myState.text =  $"����:{Player.PlayerLv}\nü��:{Player.PlayerHP}\n������:{Player.PlayerDamage + Player.sword.Damage}\n����:{Player.sword.Speed}s";
        Myimage.sprite = Player.Swordimage.sprite;
        if(curtime >= Player.sword.Speed)
        {
            enemyState.HP -= Player.PlayerDamage;
            colorC();
            //���� ������ ������ ����
            if(enemyState.HP <= 0)
            {
                Debug.Log("���� �̱�");
            }
            curtime = 0;
        }
    }

    void colorC()
    {
        Enemyimage.color = Color.red;
        Color color = Enemyimage.color;
        color.a = 1f;
        Enemyimage.color = color;
        StartCoroutine(Wait());
       
    }
    IEnumerator Wait()
    {
        yield return new WaitForSeconds(0.3f);

        Color color = Enemyimage.color;
        color.a = 0.5f;
        Enemyimage.color = color;
        Enemyimage.color = Color.black;
    }
}
