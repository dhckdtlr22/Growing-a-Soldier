using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class EnemyState : MonoBehaviour
{
   
    public Text EnemyStateText;
    public Image Playerimage;
    public int Damage;
    public int HP;
    public float Speed;
    public float CriDG;

    public float curtime;
  
    void Start()
    {
        Playerimage = GameObject.Find("Playerimage").GetComponent<Image>();
        HP = Random.Range(70, 200);
        Damage = Random.Range(10, 20);
        Speed = Random.Range(0.7f, 1.3f);
        CriDG = Random.Range(1.3f, 2f);
        
    }

    // Update is called once per frame
    void Update()
    {//�÷��̾� ������ ����� ���ȿ����� ����
        curtime += Time.deltaTime;
        EnemyStateText.text = $"ü��:{HP}\n���ݷ�:{Damage}\n����:{Speed.ToString("F1")}";
        if(curtime >= Speed)
        {
            Player.PlayerHP -= Damage;
            colorC();
            if(Player.PlayerHP <= 0)
            {
                Debug.Log("���� �̱�!!!!");
            }
            curtime = 0;
        }
    }
    void colorC()
    {
        Playerimage.color = Color.red;
        Color color = Playerimage.color;
        color.a = 1f;
        Playerimage.color = color;
        StartCoroutine(Wait());

    }
    IEnumerator Wait()
    {
        yield return new WaitForSeconds(0.3f);

        Color color = Playerimage.color;
        color.a = 0.5f;
        Playerimage.color = color;
        Playerimage.color = Color.black;
    }
}
